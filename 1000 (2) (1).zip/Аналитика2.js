const apiUrl = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=true";

async function fetchCryptoData() {
    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        const tableBody = document.getElementById("crypto-table");
        tableBody.innerHTML = ""; 

        data.forEach(coin => {
            const row = document.createElement("tr");

            row.innerHTML = `
                <td>${coin.name} (${coin.symbol.toUpperCase()})</td>
                <td>$${coin.current_price.toFixed(2)}</td>
                <td style="color: ${coin.price_change_percentage_24h >= 0 ? 'green' : 'red'};">
                    ${coin.price_change_percentage_24h.toFixed(2)}%
                </td>
                <td>$${coin.total_volume.toLocaleString()}</td>
                <td>$${coin.market_cap.toLocaleString()}</td>
                <td style="color: ${coin.price_change_percentage_7d_in_currency >= 0 ? 'green' : 'red'};">
                    ${coin.price_change_percentage_7d_in_currency ? coin.price_change_percentage_7d_in_currency.toFixed(2) : "N/A"}%
                </td>
            `;

            tableBody.appendChild(row);
        });

        updateChart(data.find(coin => coin.symbol === "btc")); // Обновляем график Bitcoin
    } catch (error) {
        console.error("Ошибка загрузки данных:", error);
    }
}

function updateChart(btcData) {
    if (!btcData || !btcData.sparkline_in_7d) return;

    const ctx = document.getElementById("btcChart").getContext("2d");

    if (window.btcChartInstance) {
        window.btcChartInstance.destroy();
    }

    window.btcChartInstance = new Chart(ctx, {
        type: "line",
        data: {
            labels: Array.from({ length: btcData.sparkline_in_7d.price.length }, (_, i) => `День ${i + 1}`),
            datasets: [{
                label: "Цена BTC (USD)",
                data: btcData.sparkline_in_7d.price,
                borderColor: "orange",
                fill: false
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: { display: false },
                y: { beginAtZero: false }
            }
        }
    });
}



fetchCryptoData();
setInterval(fetchCryptoData, 30000); // Обновление каждые 30 секунд
